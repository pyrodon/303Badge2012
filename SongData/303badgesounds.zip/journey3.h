#define MAXTRACK	0x08
#define SONGLEN		0x0a
