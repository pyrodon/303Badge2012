#define MAXTRACK	0x0d
#define SONGLEN		0x0a
