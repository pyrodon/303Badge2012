#define MAXTRACK	0x1d
#define SONGLEN		0x0a
