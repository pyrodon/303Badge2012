#define MAXTRACK	0x1a
#define SONGLEN		0x08
