#define MAXTRACK	0x0a
#define SONGLEN		0x08
