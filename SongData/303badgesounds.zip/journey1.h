#define MAXTRACK	0x1b
#define SONGLEN		0x0a
