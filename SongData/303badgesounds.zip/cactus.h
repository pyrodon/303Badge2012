#define MAXTRACK	0x04
#define SONGLEN		0x04
