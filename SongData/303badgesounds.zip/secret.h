#define MAXTRACK	0x01
#define SONGLEN		0x01
