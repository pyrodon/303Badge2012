#define MAXTRACK	0x02
#define SONGLEN		0x01
